function textAppearance(){
    document.getElementById('p_daetime').innerHTML = Date()
    elem = document.getElementById('p_daetime')
    elem.style.display = 'flex'
    var today = moment(new Date())
    today = today.format("MMMM D, YYYY h:m A")
    // elem.style.padding = '100px'
    // elem.style.color = 'red'
    // date_now = new Date().toString().
    // document.getElementById('p_daetime').innerHTML = 'Hello'
}